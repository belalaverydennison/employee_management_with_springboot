package org.belal.quarkusAPI.dto;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.List;


@JsonPropertyOrder({"departmentId", "name","totalSalary", "noOfEmployees","employees"})
public class GetAllEmployeeResponse {
    private Integer departmentId;
    @JsonProperty("Name")
    private String name;
    private Long totalSalary;
    private Long noOfEmployees;

    private List<EmployeeList> employees;

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getTotalSalary() {
        return totalSalary;
    }

    public void setTotalSalary(Long totalSalary) {
        this.totalSalary = totalSalary;
    }

    public Long getNoOfEmployees() {
        return noOfEmployees;
    }

    public void setNoOfEmployees(Long noOfEmployees) {
        this.noOfEmployees = noOfEmployees;
    }

    public List<EmployeeList> getEmployees() {
        return employees;
    }

    public void setEmployees(List<EmployeeList> employees) {
        this.employees = employees;
    }
    @JsonPropertyOrder({"employeeId","dateOfBirth","salary"})
    public static class EmployeeList {
        private Double salary;

        private String dateOfBirth;

        private String employeeId;

        public Double getSalary() {
            return salary;
        }

        public void setSalary(Double salary) {
            this.salary = salary;
        }

        public String getDateOfBirth() {
            return dateOfBirth;
        }

        public void setDateOfBirth(String dateOfBirth) {
            this.dateOfBirth = dateOfBirth;
        }

        public String getEmployeeId() {
            return employeeId;
        }

        public void setEmployeeId(String employeeId) {
            this.employeeId = employeeId;
        }
    }
}
