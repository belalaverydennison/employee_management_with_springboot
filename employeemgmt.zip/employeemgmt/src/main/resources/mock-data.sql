--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.21
-- Dumped by pg_dump version 9.6.21

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: dept; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dept (id, name) FROM stdin;
1	Developer
2	BA
\.


--
-- Name: dept_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dept_id_seq', 2, true);


--
-- Data for Name: emp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.emp (salary, department_id, id, dateofbirth, employeeid, name) FROM stdin;
300000	1	1	01 Jan 1990	TPIND004	Belal Altamash
400000	1	2	01 Jan 1990	TPIND001	Sudhakar M
1400000	2	3	01 Jan 1990	TPIND002	Poorna C
1000000	2	4	01 Jan 1990	TPIND003	Ajitesh S
\.


--
-- Name: emp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.emp_id_seq', 4, true);


--
-- Name: myentity_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.myentity_seq', 1, false);


--
-- PostgreSQL database dump complete
--

