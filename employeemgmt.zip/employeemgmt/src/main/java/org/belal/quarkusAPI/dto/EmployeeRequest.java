package org.belal.quarkusAPI.dto;

import jakarta.validation.constraints.NotNull;

public class EmployeeRequest {
    @NotNull
    private String name;
    @NotNull
    private double salary;

    private Long departmentId;
    private String employeeId;
    @NotNull
    private String departmentName;
    @NotNull
    private String dateOfBirth;

    public EmployeeRequest() {
    }

    public EmployeeRequest(String name, double salary, Long departmentId, String dateOfBirth, String departmentName, String employeeId) {
        this.name = name;
        this.salary = salary;
        this.departmentId = departmentId;
        this.dateOfBirth = dateOfBirth;
        this.departmentName = departmentName;
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
}
