package org.belal.quarkusAPI.resources;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import org.belal.quarkusAPI.dto.GetAllEmployeeResponse;
import org.belal.quarkusAPI.dto.EmployeeRequest;
import org.belal.quarkusAPI.resources.entity.Department;
import org.belal.quarkusAPI.resources.entity.Employee;


@Path("/v1/emp-mgmt-app/employees")
public class EmployeeResource {

    @Inject
    EntityManager entityManager;

    @POST
    @Transactional
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createEmployee(EmployeeRequest employeeRequest) {
        Employee employee = new Employee();
        employee.setName(employeeRequest.getName());
        employee.setSalary(employeeRequest.getSalary());
        employee.setDateOfBirth(employeeRequest.getDateOfBirth());
        employee.setEmployeeId(employeeRequest.getEmployeeId());
        Department department = null;
        if (employeeRequest.getDepartmentId() != null) {
            // Associate with an existing department
            department = entityManager.find(Department.class, employeeRequest.getDepartmentId());
        }
        if (department == null) {
            String queryString = "SELECT d FROM Department d WHERE d.name = :departmentName";
            TypedQuery<Department> query = entityManager.createQuery(queryString, Department.class);
            query.setParameter("departmentName", employeeRequest.getDepartmentName());
            List<Department> departmentList = query.getResultList();
            if (departmentList.isEmpty()) {
                department = new Department();
                department.setName(employeeRequest.getDepartmentName());
                entityManager.persist(department);
            } else {
                department = departmentList.get(0);
            }
        }

        employee.setDepartment(department);
        entityManager.persist(employee);
        return Response.status(Response.Status.CREATED).entity("Employee Successfully Added.").build();
    }

    @GET
    @Transactional
    @Produces(MediaType.APPLICATION_JSON)
    public List getAllEmployees() throws JsonProcessingException {
        String queryString = "SELECT " +
                "jsonb_build_object(" +
                "    'departmentId', d.id, " +
                "    'Name', d.name, " +
                "    'noOfEmployees', count(e.id), " +
                "    'totalSalary', sum(e.salary), " +
                "    'employees', jsonb_agg(" +
                "      jsonb_build_object(" +
                "        'employeeId', e.employeeId, " +
                "        'dateOfBirth', e.dateofbirth, " +
                "        'salary', e.salary " +
                "      )" +
                "    )" +
                ") AS department " +
                "FROM Dept d " +
                "JOIN Emp e ON d.id = e.department_id " +
                "GROUP BY d.id, d.name";

        List resultList = entityManager.createNativeQuery(queryString).getResultList();
        List<GetAllEmployeeResponse> getAllEmployeeRespons
                = new ObjectMapper().readValue(resultList.toString(), new TypeReference<List<GetAllEmployeeResponse>>() {});
        return getAllEmployeeRespons;
    }

}
