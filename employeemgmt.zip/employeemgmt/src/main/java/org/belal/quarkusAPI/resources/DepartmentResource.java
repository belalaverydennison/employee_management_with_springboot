package org.belal.quarkusAPI.resources;

import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.util.List;
import org.belal.quarkusAPI.resources.entity.Department;

@Path("/v1/emp-mgmt-app/departments")
public class DepartmentResource {

    @Inject
    EntityManager entityManager;

    @GET
    @Path("/max-salary")
    @Transactional
    @Produces(MediaType.APPLICATION_JSON)
    public Department getDepartmentWithMaxSalary() {
        TypedQuery<Department> query = entityManager.createQuery(
                "SELECT d FROM Department d WHERE d.id IN " +
                        "(SELECT e.department.id FROM Employee e WHERE e.salary = " +
                        "(SELECT MAX(e2.salary) FROM Employee e2))",
                Department.class);

        query.setMaxResults(1);
        System.out.println(query.getSingleResult());
        return query.getSingleResult();
    }

    @GET
    @Transactional
    @Produces(MediaType.APPLICATION_JSON)
    public List<Department> getAllDepartments() {
        return entityManager.createQuery("SELECT d FROM Department d", Department.class).getResultList();
    }


}
